-- Concepts are the nodes of the graph. Names are unique ignoring case.
CREATE TABLE IF NOT EXISTS concepts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL COLLATE NOCASE UNIQUE
                CHECK (length(trim(name)) BETWEEN 1 AND 80),
    discipline  TEXT NOT NULL
                CHECK (length(trim(discipline)) BETWEEN 1 AND 40),
    description TEXT NOT NULL DEFAULT ''
                CHECK (length(description) <= 500)
);

-- Relations are the edges. Deleting a concept deletes its relations.
CREATE TABLE IF NOT EXISTS relations (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    from_id  INTEGER NOT NULL REFERENCES concepts (id) ON DELETE CASCADE,
    to_id    INTEGER NOT NULL REFERENCES concepts (id) ON DELETE CASCADE,
    label    TEXT NOT NULL COLLATE NOCASE
             CHECK (length(trim(label)) BETWEEN 1 AND 60),
    strength INTEGER NOT NULL DEFAULT 3 CHECK (strength BETWEEN 1 AND 5),
    CHECK (from_id <> to_id),
    UNIQUE (from_id, to_id, label)
);

CREATE INDEX IF NOT EXISTS idx_relations_from ON relations (from_id);
CREATE INDEX IF NOT EXISTS idx_relations_to ON relations (to_id);
