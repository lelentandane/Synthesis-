/*
 * Synthesis front end.
 * - Force-directed graph layout written from scratch (repulsion, springs, gravity) and drawn on a canvas
 * - Pan, zoom, pinch and drag
 * - Panel with three tabs: Connect (find a route), Concepts (browse and edit), Insights (analysis)
 * All text from the server is inserted with textContent, never as HTML.
 */
(function () {
  "use strict";

  // ------------------------------------------------------------------ small helpers

  const $ = (selector, root) => (root || document).querySelector(selector);
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /** Builds an element. Children can be nodes, strings or arrays of either. */
  function h(tag, attrs, ...children) {
    const node = document.createElement(tag);
    Object.entries(attrs || {}).forEach(([key, value]) => {
      if (value === false || value === null || value === undefined) return;
      if (key === "class") node.className = value;
      else if (key === "text") node.textContent = value;
      else if (key.startsWith("on")) node.addEventListener(key.slice(2), value);
      else node.setAttribute(key, value === true ? "" : value);
    });
    children.flat().forEach((child) => {
      if (child === null || child === undefined || child === false) return;
      node.append(child.nodeType ? child : document.createTextNode(String(child)));
    });
    return node;
  }

  async function api(path, options) {
    const opts = options || {};
    const init = { method: opts.method || "GET", headers: {} };
    if (opts.body !== undefined) {
      init.headers["Content-Type"] = "application/json";
      init.body = JSON.stringify(opts.body);
    }
    const response = await fetch(path, init);
    let data = null;
    try { data = await response.json(); } catch (ignored) { /* no body */ }
    if (!response.ok) throw new Error((data && data.error) || "Something went wrong. Please try again.");
    return data;
  }

  let toastTimer = null;
  function toast(message, isError) {
    const node = $("#toast");
    node.textContent = message;
    node.classList.toggle("is-error", Boolean(isError));
    node.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => node.classList.remove("is-visible"), isError ? 5000 : 2800);
  }

  function dots(strength) {
    return h("span", { class: "dots", role: "img", "aria-label": "Strength " + strength + " of 5" },
      "\u25CF".repeat(strength) + "\u25CB".repeat(5 - strength));
  }

  // ------------------------------------------------------------------ state

  const PALETTE = ["#2f7d6d", "#c0562f", "#3f5fa8", "#b08a1e", "#8b4c8f", "#5c8a3a", "#c4476b", "#5b6e7a"];
  const INK = "#15302b";
  const SOFT = "#4a5e59";
  const BONE = "#fbf9f3";
  const ACCENT = "#99490f";

  const state = {
    concepts: [],
    relations: [],
    byId: new Map(),
    links: new Map(),         // id -> [{ relation, otherId, forward }]
    disciplines: [],          // sorted names
    selectedId: null,
    hoverId: null,
    search: "",
    hidden: new Set(),        // hidden discipline names
    result: null,             // path search result
    routeIndex: 0,
    editingId: null,
    insightsStale: true
  };

  function colorOf(discipline) {
    const index = state.disciplines.indexOf(discipline);
    return PALETTE[(index < 0 ? 0 : index) % PALETTE.length];
  }

  function rebuildIndexes() {
    state.byId = new Map(state.concepts.map((c) => [c.id, c]));
    state.links = new Map(state.concepts.map((c) => [c.id, []]));
    state.relations.forEach((r) => {
      if (!state.byId.has(r.fromId) || !state.byId.has(r.toId)) return;
      state.links.get(r.fromId).push({ relation: r, otherId: r.toId, forward: true });
      state.links.get(r.toId).push({ relation: r, otherId: r.fromId, forward: false });
    });
    state.disciplines = Array.from(new Set(state.concepts.map((c) => c.discipline)))
      .sort((a, b) => a.localeCompare(b));
    state.hidden.forEach((name) => { if (!state.disciplines.includes(name)) state.hidden.delete(name); });
  }

  const degreeOf = (id) => (state.links.get(id) || []).length;
  const isVisible = (id) => state.byId.has(id) && !state.hidden.has(state.byId.get(id).discipline);

  // ------------------------------------------------------------------ force layout

  const sim = { nodes: new Map(), alpha: 0, reset: false };

  function syncNodes() {
    const next = new Map();
    state.concepts.forEach((concept, index) => {
      let node = sim.nodes.get(concept.id);
      if (!node) {
        // Start near a concept it is linked to if possible, otherwise on a spiral.
        const anchor = (state.links.get(concept.id) || [])
          .map((l) => sim.nodes.get(l.otherId)).find(Boolean);
        if (anchor) {
          node = { id: concept.id, x: anchor.x + (Math.random() - 0.5) * 60, y: anchor.y + (Math.random() - 0.5) * 60, vx: 0, vy: 0 };
        } else {
          const angle = index * 2.399963;
          const radius = 30 + 24 * Math.sqrt(index);
          node = { id: concept.id, x: Math.cos(angle) * radius, y: Math.sin(angle) * radius, vx: 0, vy: 0 };
        }
      }
      next.set(concept.id, node);
    });
    sim.nodes = next;
  }

  function tick() {
    const nodes = Array.from(sim.nodes.values());
    const alpha = sim.alpha;

    // Repulsion between every pair of concepts.
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i];
        const b = nodes[j];
        let dx = b.x - a.x;
        let dy = b.y - a.y;
        let d2 = dx * dx + dy * dy;
        if (d2 < 1) { dx = Math.random() - 0.5; dy = Math.random() - 0.5; d2 = 1; }
        const d = Math.sqrt(d2);
        const force = Math.min((11000 * alpha) / d2, 45);
        const fx = (dx / d) * force;
        const fy = (dy / d) * force;
        a.vx -= fx; a.vy -= fy;
        b.vx += fx; b.vy += fy;
      }
    }

    // Springs along relations: stronger relations pull concepts closer.
    state.relations.forEach((relation) => {
      const a = sim.nodes.get(relation.fromId);
      const b = sim.nodes.get(relation.toId);
      if (!a || !b) return;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const d = Math.sqrt(dx * dx + dy * dy) || 1;
      const rest = 200 - relation.strength * 16;
      const force = (d - rest) * 0.05 * alpha;
      const fx = (dx / d) * force;
      const fy = (dy / d) * force;
      a.vx += fx; a.vy += fy;
      b.vx -= fx; b.vy -= fy;
    });

    // Gentle pull toward the centre and toward the middle of each discipline.
    const centres = new Map();
    state.concepts.forEach((c) => {
      const n = sim.nodes.get(c.id);
      if (!n) return;
      const entry = centres.get(c.discipline) || { x: 0, y: 0, count: 0 };
      entry.x += n.x; entry.y += n.y; entry.count++;
      centres.set(c.discipline, entry);
    });
    state.concepts.forEach((c) => {
      const n = sim.nodes.get(c.id);
      const centre = centres.get(c.discipline);
      if (!n || !centre) return;
      n.vx += (centre.x / centre.count - n.x) * 0.008 * alpha - n.x * 0.006 * alpha;
      n.vy += (centre.y / centre.count - n.y) * 0.008 * alpha - n.y * 0.006 * alpha;
    });

    nodes.forEach((n) => {
      if (n === drag.node) { n.vx = 0; n.vy = 0; return; }
      n.vx *= 0.82; n.vy *= 0.82;
      n.x += n.vx; n.y += n.vy;
    });
    sim.alpha *= 0.985;
  }

  /** Runs the layout ahead of time so the first thing you see is already settled. */
  function settle() {
    sim.alpha = 1;
    const steps = state.concepts.length <= 150 ? 220 : 70;
    for (let i = 0; i < steps; i++) tick();
    sim.alpha = reducedMotion ? 0 : 0.05;
  }

  // ------------------------------------------------------------------ canvas

  const canvas = $("#graph");
  const ctx = canvas.getContext("2d");
  const view = { x: 0, y: 0, k: 1 };
  const drag = { mode: null, node: null, moved: false, startX: 0, startY: 0, viewX: 0, viewY: 0 };
  const pointers = new Map();
  let pinch = null;
  let frameQueued = false;
  let sized = false;

  function resizeCanvas() {
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth;
    const h2 = canvas.clientHeight;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h2 * dpr);
    if (!sized && w > 0) { sized = true; fitTo(visibleIds()); }
    requestDraw();
  }

  function requestDraw() {
    if (frameQueued) return;
    frameQueued = true;
    requestAnimationFrame(frame);
  }

  function frame() {
    frameQueued = false;
    if (sim.alpha > 0.02) tick();
    draw();
    if (sim.alpha > 0.02 || drag.mode) requestDraw();
  }

  const visibleIds = () => state.concepts.filter((c) => isVisible(c.id)).map((c) => c.id);
  const radiusOf = (id) => 5 + Math.sqrt(degreeOf(id)) * 2.2;

  function fitTo(ids, options) {
    const opts = Object.assign({ maxZoom: 1.4, padding: 60 }, options);
    const nodes = ids.map((id) => sim.nodes.get(id)).filter(Boolean);
    const w = canvas.clientWidth;
    const h2 = canvas.clientHeight;
    if (!nodes.length || w === 0) return;
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    nodes.forEach((n) => {
      minX = Math.min(minX, n.x); maxX = Math.max(maxX, n.x);
      minY = Math.min(minY, n.y); maxY = Math.max(maxY, n.y);
    });
    const boundsW = Math.max(maxX - minX, 80);
    const boundsH = Math.max(maxY - minY, 80);
    // Leave room at the bottom for the discipline legend and zoom buttons.
    const reserve = w < 700 ? 110 : 56;
    const usable = h2 - reserve;
    const k = clamp(Math.min((w - opts.padding * 2) / boundsW, (usable - opts.padding * 2) / boundsH), 0.2, opts.maxZoom);
    view.k = k;
    view.x = w / 2 - ((minX + maxX) / 2) * k;
    view.y = usable / 2 + 20 - ((minY + maxY) / 2) * k;
    requestDraw();
  }

  function zoomAt(sx, sy, factor) {
    const k = clamp(view.k * factor, 0.15, 4);
    const wx = (sx - view.x) / view.k;
    const wy = (sy - view.y) / view.k;
    view.k = k;
    view.x = sx - wx * k;
    view.y = sy - wy * k;
    requestDraw();
  }

  // What is emphasised right now: a route, a selected concept, or search matches.
  function emphasis() {
    const route = currentRoute();
    const search = state.search.trim().toLowerCase();
    const matches = new Set();
    if (search) state.concepts.forEach((c) => { if (c.name.toLowerCase().includes(search)) matches.add(c.id); });
    const focusId = state.selectedId !== null ? state.selectedId : state.hoverId;
    const neighbours = new Set();
    if (focusId !== null) (state.links.get(focusId) || []).forEach((l) => neighbours.add(l.otherId));
    return {
      route,
      routeNodes: route ? new Set(route.conceptIds) : null,
      routeEdges: route ? new Set(route.steps.map((s) => s.relationId)) : null,
      search, matches, focusId, neighbours
    };
  }

  function draw() {
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth;
    const h2 = canvas.clientHeight;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h2);
    if (!state.concepts.length) return;

    const e = emphasis();
    const nodeAlpha = (id) => {
      if (e.routeNodes) return e.routeNodes.has(id) ? 1 : 0.18;
      if (e.focusId !== null) return id === e.focusId || e.neighbours.has(id) ? 1 : 0.3;
      if (e.search) return e.matches.has(id) ? 1 : 0.15;
      return 1;
    };

    // ---- edges (world space)
    ctx.save();
    ctx.translate(view.x, view.y);
    ctx.scale(view.k, view.k);
    const labels = [];
    const normal = [];
    const emphasised = [];
    state.relations.forEach((r) => {
      if (!isVisible(r.fromId) || !isVisible(r.toId)) return;
      const onRoute = e.routeEdges && e.routeEdges.has(r.id);
      const onFocus = !e.routeEdges && e.focusId !== null && (r.fromId === e.focusId || r.toId === e.focusId);
      (onRoute || onFocus ? emphasised : normal).push({ r, onRoute });
    });
    const drawEdge = (item, alpha, color, width) => {
      const a = sim.nodes.get(item.r.fromId);
      const b = sim.nodes.get(item.r.toId);
      if (!a || !b) return;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const d = Math.sqrt(dx * dx + dy * dy) || 1;
      const ux = dx / d;
      const uy = dy / d;
      const ra = radiusOf(item.r.fromId) + 2;
      const rb = radiusOf(item.r.toId) + 3;
      const x1 = a.x + ux * ra, y1 = a.y + uy * ra;
      const x2 = b.x - ux * rb, y2 = b.y - uy * rb;
      ctx.globalAlpha = alpha;
      ctx.strokeStyle = color;
      ctx.lineWidth = width;
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      if (view.k >= 0.7 && d > ra + rb + 14) {
        const size = 6 + width;
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.moveTo(x2, y2);
        ctx.lineTo(x2 - ux * size - uy * size * 0.5, y2 - uy * size + ux * size * 0.5);
        ctx.lineTo(x2 - ux * size + uy * size * 0.5, y2 - uy * size - ux * size * 0.5);
        ctx.closePath(); ctx.fill();
      }
    };
    const dim = e.routeEdges || e.focusId !== null || e.search;
    normal.forEach((item) => drawEdge(item, dim ? 0.1 : 0.4, SOFT, 0.8 + item.r.strength * 0.25));
    emphasised.forEach((item) => {
      drawEdge(item, 1, item.onRoute ? ACCENT : INK, item.onRoute ? 3 : 1.6 + item.r.strength * 0.3);
      const a = sim.nodes.get(item.r.fromId);
      const b = sim.nodes.get(item.r.toId);
      if (a && b && view.k >= 0.55) labels.push({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, text: item.r.label, route: item.onRoute });
    });

    // ---- nodes (world space)
    const stepNumbers = new Map();
    if (e.route) e.route.conceptIds.forEach((id, index) => { if (!stepNumbers.has(id)) stepNumbers.set(id, index + 1); });
    state.concepts.forEach((c) => {
      if (!isVisible(c.id)) return;
      const n = sim.nodes.get(c.id);
      if (!n) return;
      const r = radiusOf(c.id);
      ctx.globalAlpha = nodeAlpha(c.id);
      ctx.fillStyle = colorOf(c.discipline);
      ctx.beginPath(); ctx.arc(n.x, n.y, r, 0, Math.PI * 2); ctx.fill();
      ctx.lineWidth = 1.8; ctx.strokeStyle = BONE; ctx.stroke();
      if (c.id === state.selectedId || (e.routeNodes && e.routeNodes.has(c.id))) {
        ctx.lineWidth = 3; ctx.strokeStyle = e.routeNodes ? ACCENT : INK;
        ctx.beginPath(); ctx.arc(n.x, n.y, r + 4, 0, Math.PI * 2); ctx.stroke();
      }
      if (e.search && e.matches.has(c.id) && !e.routeNodes) {
        ctx.lineWidth = 2.5; ctx.strokeStyle = ACCENT;
        ctx.beginPath(); ctx.arc(n.x, n.y, r + 4, 0, Math.PI * 2); ctx.stroke();
      }
    });
    ctx.restore();

    // ---- text (screen space, so it stays a constant size)
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.textBaseline = "middle";
    const topIds = new Set(
      state.concepts.slice().sort((a, b) => degreeOf(b.id) - degreeOf(a.id)).slice(0, 10).map((c) => c.id));

    state.concepts.forEach((c) => {
      if (!isVisible(c.id)) return;
      const important = c.id === state.selectedId || c.id === state.hoverId
        || (e.routeNodes && e.routeNodes.has(c.id)) || (e.search && e.matches.has(c.id))
        || (e.focusId !== null && e.neighbours.has(c.id));
      if (!(important || view.k >= 0.95 || (view.k >= 0.3 && topIds.has(c.id)))) return;
      const n = sim.nodes.get(c.id);
      if (!n) return;
      const sx = n.x * view.k + view.x;
      const sy = n.y * view.k + view.y;
      if (sx < -80 || sy < -20 || sx > canvas.clientWidth + 80 || sy > canvas.clientHeight + 20) return;
      ctx.globalAlpha = nodeAlpha(c.id);
      ctx.font = (important ? "600 " : "500 ") + "13px 'Hanken Grotesk', system-ui, sans-serif";
      ctx.textAlign = "left";
      ctx.lineWidth = 4; ctx.strokeStyle = BONE; ctx.lineJoin = "round";
      const tx = sx + radiusOf(c.id) * view.k + 6;
      ctx.strokeText(c.name, tx, sy);
      ctx.fillStyle = INK;
      ctx.fillText(c.name, tx, sy);
    });

    ctx.globalAlpha = 1;
    labels.forEach((label) => {
      ctx.font = "italic 400 13px 'Instrument Serif', Georgia, serif";
      ctx.textAlign = "center";
      const sx = label.x * view.k + view.x;
      const sy = label.y * view.k + view.y - 9;
      ctx.lineWidth = 4; ctx.strokeStyle = BONE;
      ctx.strokeText(label.text, sx, sy);
      ctx.fillStyle = label.route ? ACCENT : SOFT;
      ctx.fillText(label.text, sx, sy);
    });

    // route step numbers
    stepNumbers.forEach((number, id) => {
      const n = sim.nodes.get(id);
      if (!n) return;
      const sx = n.x * view.k + view.x;
      const sy = n.y * view.k + view.y - (radiusOf(id) * view.k + 15);
      ctx.fillStyle = ACCENT;
      ctx.beginPath(); ctx.arc(sx, sy, 9, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.font = "600 11px 'Hanken Grotesk', system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(String(number), sx, sy + 0.5);
    });
  }

  // ---- pointer interaction

  function localPoint(event) {
    const rect = canvas.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }

  function hitNode(point) {
    const wx = (point.x - view.x) / view.k;
    const wy = (point.y - view.y) / view.k;
    let best = null;
    sim.nodes.forEach((n, id) => {
      if (!isVisible(id)) return;
      const r = radiusOf(id) + 5 / view.k;
      const d2 = (n.x - wx) * (n.x - wx) + (n.y - wy) * (n.y - wy);
      if (d2 <= r * r && (best === null || d2 < best.d2)) best = { node: n, d2 };
    });
    return best ? best.node : null;
  }

  canvas.addEventListener("pointerdown", (event) => {
    canvas.setPointerCapture(event.pointerId);
    const point = localPoint(event);
    pointers.set(event.pointerId, point);

    if (pointers.size === 2) {
      const [a, b] = Array.from(pointers.values());
      pinch = { distance: Math.hypot(a.x - b.x, a.y - b.y) };
      drag.mode = null; drag.node = null;
      return;
    }
    const hit = hitNode(point);
    drag.mode = hit ? "node" : "pan";
    drag.node = hit;
    drag.moved = false;
    drag.startX = point.x; drag.startY = point.y;
    drag.viewX = view.x; drag.viewY = view.y;
    canvas.classList.add("is-dragging");
  });

  canvas.addEventListener("pointermove", (event) => {
    const point = localPoint(event);
    if (pointers.has(event.pointerId)) pointers.set(event.pointerId, point);

    if (pinch && pointers.size === 2) {
      const [a, b] = Array.from(pointers.values());
      const distance = Math.hypot(a.x - b.x, a.y - b.y);
      if (pinch.distance > 0) zoomAt((a.x + b.x) / 2, (a.y + b.y) / 2, distance / pinch.distance);
      pinch.distance = distance;
      return;
    }

    if (drag.mode) {
      const dx = point.x - drag.startX;
      const dy = point.y - drag.startY;
      if (!drag.moved && Math.hypot(dx, dy) > 4) drag.moved = true;
      if (drag.moved) {
        if (drag.mode === "pan") {
          view.x = drag.viewX + dx;
          view.y = drag.viewY + dy;
        } else if (drag.node) {
          drag.node.x = (point.x - view.x) / view.k;
          drag.node.y = (point.y - view.y) / view.k;
          sim.alpha = Math.max(sim.alpha, 0.3);
        }
        requestDraw();
      }
      return;
    }

    const hit = hitNode(point);
    const id = hit ? hit.id : null;
    canvas.classList.toggle("is-pointer", Boolean(hit));
    if (id !== state.hoverId) { state.hoverId = id; requestDraw(); }
  });

  function endPointer(event) {
    pointers.delete(event.pointerId);
    if (pinch) { if (pointers.size < 2) pinch = null; return; }
    if (!drag.mode) return;
    if (!drag.moved) {
      if (drag.node) selectConcept(drag.node.id, { fromCanvas: true });
      else if (state.selectedId !== null) { state.selectedId = null; renderDetail(); renderList(); requestDraw(); }
    }
    drag.mode = null; drag.node = null;
    canvas.classList.remove("is-dragging");
    requestDraw();
  }
  canvas.addEventListener("pointerup", endPointer);
  canvas.addEventListener("pointercancel", endPointer);
  canvas.addEventListener("pointerleave", () => { if (state.hoverId !== null && !drag.mode) { state.hoverId = null; requestDraw(); } });

  canvas.addEventListener("wheel", (event) => {
    event.preventDefault();
    const point = localPoint(event);
    zoomAt(point.x, point.y, Math.exp(-event.deltaY * 0.0015));
  }, { passive: false });

  $("#zoom-in").addEventListener("click", () => zoomAt(canvas.clientWidth / 2, canvas.clientHeight / 2, 1.3));
  $("#zoom-out").addEventListener("click", () => zoomAt(canvas.clientWidth / 2, canvas.clientHeight / 2, 1 / 1.3));
  $("#zoom-fit").addEventListener("click", () => fitTo(visibleIds()));
  new ResizeObserver(resizeCanvas).observe(canvas);

  // ------------------------------------------------------------------ tabs

  const tabs = Array.from(document.querySelectorAll('[role="tab"]'));

  function showTab(name, focus) {
    tabs.forEach((tab) => {
      const on = tab.id === "tab-" + name;
      tab.setAttribute("aria-selected", on ? "true" : "false");
      tab.tabIndex = on ? 0 : -1;
      document.getElementById(tab.getAttribute("aria-controls")).hidden = !on;
      if (on && focus) tab.focus();
    });
    if (name === "insights") loadInsights();
  }

  tabs.forEach((tab, index) => {
    tab.addEventListener("click", () => showTab(tab.id.replace("tab-", "")));
    tab.addEventListener("keydown", (event) => {
      let next = null;
      if (event.key === "ArrowRight") next = tabs[(index + 1) % tabs.length];
      if (event.key === "ArrowLeft") next = tabs[(index - 1 + tabs.length) % tabs.length];
      if (event.key === "Home") next = tabs[0];
      if (event.key === "End") next = tabs[tabs.length - 1];
      if (next) { event.preventDefault(); showTab(next.id.replace("tab-", ""), true); }
    });
  });

  // ------------------------------------------------------------------ data loading

  async function refresh() {
    const data = await api("/api/graph");
    state.concepts = data.concepts;
    state.relations = data.relations;
    rebuildIndexes();
    if (state.selectedId !== null && !state.byId.has(state.selectedId)) state.selectedId = null;
    if (state.result && !(state.byId.has(state.result.fromId) && state.byId.has(state.result.toId))) clearResult();

    if (sim.reset) { sim.nodes = new Map(); sim.reset = false; }
    const hadNodes = sim.nodes.size > 0;
    syncNodes();
    if (!hadNodes) {
      settle();
      fitTo(visibleIds());
    } else {
      sim.alpha = reducedMotion ? 0 : 0.5;
    }
    state.insightsStale = true;
    renderAll();
  }

  function renderAll() {
    renderLegend();
    renderSelects();
    renderList();
    renderDetail();
    renderResult();
    renderDisciplineOptions();
    $("#concept-count").textContent = String(state.concepts.length);
    $("#empty").hidden = state.concepts.length > 0;
    $("#graph-hint").hidden = state.concepts.length === 0;
    canvas.setAttribute("aria-label", "Graph of " + state.concepts.length + " concepts and "
      + state.relations.length + " links. The Concepts tab lists the same information as text.");
    if (!$("#view-insights").hidden) loadInsights();
    requestDraw();
  }

  // ------------------------------------------------------------------ legend and search

  function renderLegend() {
    const legend = $("#legend");
    legend.textContent = "";
    state.disciplines.forEach((name) => {
      const count = state.concepts.filter((c) => c.discipline === name).length;
      const button = h("button", {
        type: "button",
        "aria-pressed": state.hidden.has(name) ? "false" : "true",
        title: "Show or hide " + name,
        onclick: () => {
          if (state.hidden.has(name)) state.hidden.delete(name); else state.hidden.add(name);
          if (state.selectedId !== null && !isVisible(state.selectedId)) state.selectedId = null;
          renderLegend(); renderList(); renderDetail(); requestDraw();
        }
      }, h("span", { class: "swatch" }), name + " (" + count + ")");
      $(".swatch", button).style.background = colorOf(name);
      legend.append(h("li", null, button));
    });
  }

  $("#search").addEventListener("input", (event) => {
    state.search = event.target.value;
    renderList();
    requestDraw();
  });
  $("#search").addEventListener("keydown", (event) => {
    if (event.key !== "Enter") return;
    event.preventDefault();
    const term = state.search.trim().toLowerCase();
    const match = state.concepts.find((c) => isVisible(c.id) && c.name.toLowerCase().includes(term));
    if (term && match) selectConcept(match.id, { fit: true });
  });

  // ------------------------------------------------------------------ selects (Connect tab)

  function fillSelect(select, keepValue) {
    const previous = keepValue ? select.value : "";
    select.textContent = "";
    select.append(h("option", { value: "" }, "Choose\u2026"));
    state.disciplines.forEach((discipline) => {
      const group = h("optgroup", { label: discipline });
      state.concepts.filter((c) => c.discipline === discipline)
        .forEach((c) => group.append(h("option", { value: String(c.id) }, c.name)));
      select.append(group);
    });
    if (previous && state.byId.has(Number(previous))) select.value = previous;
  }

  function renderSelects() {
    fillSelect($("#from-select"), true);
    fillSelect($("#to-select"), true);
  }

  $("#swap").addEventListener("click", () => {
    const from = $("#from-select");
    const to = $("#to-select");
    const keep = from.value;
    from.value = to.value;
    to.value = keep;
  });

  // ------------------------------------------------------------------ finding a connection

  function currentRoute() {
    if (!state.result || !state.result.found) return null;
    const routes = [state.result].concat(state.result.alternatives || []);
    return routes[state.routeIndex] || routes[0];
  }

  function clearResult() {
    state.result = null;
    state.routeIndex = 0;
    $("#path-result").textContent = "";
    requestDraw();
  }

  $("#connect-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const from = $("#from-select").value;
    const to = $("#to-select").value;
    if (!from || !to) { toast("Choose both concepts first.", true); return; }
    if (from === to) { toast("Choose two different concepts.", true); return; }
    const mode = $('input[name="mode"]:checked').value;
    try {
      const result = await api("/api/path?from=" + from + "&to=" + to + "&mode=" + mode);
      result.fromId = Number(from);
      result.toId = Number(to);
      state.result = result;
      state.routeIndex = 0;
      state.selectedId = null;
      renderResult();
      renderDetail();
      renderList();
      if (result.found) fitTo(result.conceptIds, { maxZoom: 1.2, padding: 90 });
      requestDraw();
    } catch (error) {
      toast(error.message, true);
    }
  });

  function renderResult() {
    const box = $("#path-result");
    box.textContent = "";
    const result = state.result;
    if (!result) return;
    if (!result.found) {
      box.append(h("div", { class: "notice" }, h("p", { text: result.summary }),
        h("p", { class: "empty-text", text: "Add a link between the two groups, or look at the Insights tab for suggestions." })));
      return;
    }
    const routes = [result].concat(result.alternatives || []);
    const route = routes[state.routeIndex] || result;

    box.append(
      h("p", { class: "path-summary", text: route.summary }),
      h("p", { class: "path-meta", text: route.length + (route.length === 1 ? " step" : " steps")
        + ", total strength " + route.strength + (state.routeIndex > 0 ? " (alternative route)" : "") }),
      h("ol", { class: "steps" }, route.steps.map((step) => h("li", null, step.sentence, h("span", { class: "strength" }, dots(step.strength))))),
      h("button", { type: "button", class: "button button-quiet button-small", onclick: clearResult }, "Clear the route")
    );

    if (routes.length > 1) {
      const list = h("ul", { class: "routes" });
      routes.forEach((candidate, index) => {
        if (index === state.routeIndex) return;
        const names = candidate.conceptIds.map((id) => state.byId.get(id) ? state.byId.get(id).name : "?").join(" \u2192 ");
        list.append(h("li", null, h("button", {
          type: "button", class: "route-button", "aria-pressed": "false",
          onclick: () => { state.routeIndex = index; renderResult(); fitTo(candidate.conceptIds, { maxZoom: 1.2, padding: 90 }); requestDraw(); }
        }, (index === 0 ? "Back to the best route" : "Another route: " + candidate.length + " steps"),
        h("span", { class: "route-names", text: names }))));
      });
      const heading = h("h3", { text: "Other routes" });
      heading.style.margin = "1.5rem 0 0.6rem";
      box.append(heading, list);
    }
  }

  // ------------------------------------------------------------------ concepts tab: list

  function renderList() {
    const container = $("#concept-list");
    const note = $("#list-note");
    container.textContent = "";
    const term = state.search.trim().toLowerCase();
    const shown = state.concepts.filter((c) => isVisible(c.id) && (!term || c.name.toLowerCase().includes(term)));

    note.hidden = shown.length > 0 && state.concepts.length > 0;
    if (!note.hidden) {
      note.textContent = state.concepts.length === 0
        ? "No concepts yet. Choose New concept to add the first one."
        : "No concepts match your search or the disciplines currently shown.";
    }

    state.disciplines.forEach((discipline) => {
      const items = shown.filter((c) => c.discipline === discipline);
      if (!items.length) return;
      const heading = h("h3", null, h("span", { class: "swatch" }), discipline);
      $(".swatch", heading).style.background = colorOf(discipline);
      const list = h("ul", null, items.map((c) => h("li", null, h("button", {
        type: "button", class: "concept-row", "aria-current": c.id === state.selectedId ? "true" : false,
        onclick: () => selectConcept(c.id, { fit: true })
      }, h("span", null, c.name), h("span", { class: "links" }, degreeOf(c.id) + (degreeOf(c.id) === 1 ? " link" : " links"))))));
      container.append(heading, list);
    });
  }

  // ------------------------------------------------------------------ concepts tab: detail

  function selectConcept(id, options) {
    const opts = options || {};
    state.selectedId = id;
    if (state.result) { state.result = null; $("#path-result").textContent = ""; }
    showTab("concepts");
    renderDetail();
    renderList();
    if (opts.fit) {
      const around = [id].concat((state.links.get(id) || []).map((l) => l.otherId));
      fitTo(around, { maxZoom: 1.3, padding: 100 });
    }
    requestDraw();
    const detail = $("#detail");
    $("#view-concepts").scrollTop = 0;
    // On narrow screens the panel sits below the graph, so bring the details into view.
    if (!detail.hidden && window.innerWidth <= 900) {
      detail.scrollIntoView({ block: "start", behavior: reducedMotion ? "auto" : "smooth" });
    }
  }

  function renderDetail() {
    const box = $("#detail");
    box.textContent = "";
    const concept = state.byId.get(state.selectedId);
    if (!concept || !isVisible(concept.id)) { box.hidden = true; return; }
    box.hidden = false;

    const pill = h("span", { class: "pill" }, h("span", { class: "swatch" }), concept.discipline);
    $(".swatch", pill).style.background = colorOf(concept.discipline);
    const links = state.links.get(concept.id) || [];

    box.append(
      h("h2", { text: concept.name }),
      pill,
      h("p", { class: "description", text: concept.description || "No description yet." }),
      h("div", { class: "actions" },
        h("button", { type: "button", class: "button button-small", onclick: () => { $("#from-select").value = String(concept.id); showTab("connect", true); } }, "Start a route here"),
        h("button", { type: "button", class: "button button-quiet button-small", onclick: () => { $("#to-select").value = String(concept.id); showTab("connect", true); } }, "End a route here"),
        h("button", { type: "button", class: "button button-quiet button-small", onclick: () => openConceptForm(concept) }, "Edit"),
        h("button", { type: "button", class: "button button-danger button-small", onclick: () => deleteConcept(concept) }, "Delete")
      ),
      h("h3", { text: "Links (" + links.length + ")" })
    );

    if (!links.length) {
      box.append(h("p", { class: "empty-text", text: "Nothing is linked to this concept yet." }));
    } else {
      const list = h("ul", { class: "link-list" });
      links.forEach((link) => {
        const other = state.byId.get(link.otherId);
        const jump = h("button", { type: "button", class: "jump", onclick: () => selectConcept(other.id, { fit: true }) }, other.name);
        const sentence = link.forward
          ? [concept.name + " " + link.relation.label + " ", jump]
          : [jump, " " + link.relation.label + " " + concept.name];
        list.append(h("li", null,
          h("span", { class: "link-text" }, sentence, " ", dots(link.relation.strength)),
          h("button", { type: "button", class: "link-delete", "aria-label": "Delete this link", onclick: () => deleteRelation(link.relation.id) }, "Delete")));
      });
      box.append(list);
    }
    box.append(buildLinkForm(concept));
  }

  function buildLinkForm(concept) {
    const others = state.concepts.filter((c) => c.id !== concept.id);
    if (!others.length) return h("p", { class: "empty-text", text: "Add another concept to create a link." });

    const select = h("select", { id: "link-other" }, h("option", { value: "" }, "Choose a concept"));
    state.disciplines.forEach((discipline) => {
      const group = h("optgroup", { label: discipline });
      others.filter((c) => c.discipline === discipline).forEach((c) => group.append(h("option", { value: String(c.id) }, c.name)));
      if (group.children.length) select.append(group);
    });
    const labels = Array.from(new Set(state.relations.map((r) => r.label))).sort();
    const datalist = h("datalist", { id: "label-options" }, labels.map((label) => h("option", { value: label })));
    const labelInput = h("input", { id: "link-label", type: "text", maxlength: "60", list: "label-options", autocomplete: "off", placeholder: "for example: influences" });
    const strength = h("select", { id: "link-strength" },
      [1, 2, 3, 4, 5].map((n) => h("option", { value: String(n), selected: n === 3 }, n + (n === 1 ? " (loose)" : n === 5 ? " (close)" : ""))));

    return h("form", {
      class: "add-link", novalidate: true,
      onsubmit: async (event) => {
        event.preventDefault();
        const otherId = Number(select.value);
        const direction = $('input[name="link-direction"]:checked', event.target).value;
        if (!otherId) { toast("Choose the concept to link to.", true); return; }
        const body = direction === "out"
          ? { fromId: concept.id, toId: otherId } : { fromId: otherId, toId: concept.id };
        body.label = labelInput.value;
        body.strength = Number(strength.value);
        try {
          await api("/api/relations", { method: "POST", body });
          toast("Link added.");
          await refresh();
        } catch (error) { toast(error.message, true); }
      }
    },
      h("h3", { text: "Add a link" }),
      h("div", { class: "field" }, h("label", { for: "link-other" }, "Linked concept"), select),
      h("fieldset", { class: "modes" },
        h("legend", { class: "visually-hidden" }, "Direction"),
        h("label", { class: "mode" }, h("input", { type: "radio", name: "link-direction", value: "out", checked: true }), h("span", null, concept.name + " \u2192 other")),
        h("label", { class: "mode" }, h("input", { type: "radio", name: "link-direction", value: "in" }), h("span", null, "other \u2192 " + concept.name))),
      h("div", { class: "inline-fields" },
        h("div", { class: "field" }, h("label", { for: "link-label" }, "How are they linked?"), labelInput, datalist),
        h("div", { class: "field" }, h("label", { for: "link-strength" }, "Strength"), strength)),
      h("button", { class: "button button-small", type: "submit" }, "Add link"));
  }

  async function deleteRelation(id) {
    try {
      await api("/api/relations/" + id, { method: "DELETE" });
      toast("Link deleted.");
      await refresh();
    } catch (error) { toast(error.message, true); }
  }

  async function deleteConcept(concept) {
    if (!window.confirm("Delete \"" + concept.name + "\" and all of its links?")) return;
    try {
      await api("/api/concepts/" + concept.id, { method: "DELETE" });
      state.selectedId = null;
      toast("Concept deleted.");
      await refresh();
    } catch (error) { toast(error.message, true); }
  }

  // ------------------------------------------------------------------ concepts tab: create and edit

  function renderDisciplineOptions() {
    const list = $("#discipline-options");
    list.textContent = "";
    state.disciplines.forEach((name) => list.append(h("option", { value: name })));
  }

  function openConceptForm(concept) {
    state.editingId = concept ? concept.id : null;
    $("#concept-form-title").textContent = concept ? "Edit concept" : "New concept";
    $("#concept-save").textContent = concept ? "Save changes" : "Save concept";
    $("#concept-name").value = concept ? concept.name : "";
    $("#concept-discipline").value = concept ? concept.discipline : "";
    $("#concept-description").value = concept ? concept.description : "";
    $("#concept-error").hidden = true;
    $("#concept-form").hidden = false;
    showTab("concepts");
    $("#concept-name").focus();
  }

  function closeConceptForm() {
    $("#concept-form").hidden = true;
    state.editingId = null;
  }

  $("#new-concept").addEventListener("click", () => openConceptForm(null));
  $("#concept-cancel").addEventListener("click", closeConceptForm);
  $("#empty-add").addEventListener("click", () => openConceptForm(null));

  $("#concept-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const body = {
      name: $("#concept-name").value,
      discipline: $("#concept-discipline").value,
      description: $("#concept-description").value
    };
    const wasEditing = Boolean(state.editingId);
    try {
      let saved;
      if (wasEditing) saved = await api("/api/concepts/" + state.editingId, { method: "PUT", body });
      else saved = await api("/api/concepts", { method: "POST", body });
      closeConceptForm();
      toast(wasEditing ? "Concept updated." : "Concept added.");
      state.selectedId = saved.id;
      await refresh();
      selectConcept(saved.id, { fit: false });
    } catch (error) {
      const box = $("#concept-error");
      box.textContent = error.message;
      box.hidden = false;
    }
  });

  // ------------------------------------------------------------------ insights tab

  async function loadInsights() {
    if (!state.insightsStale) return;
    const box = $("#insights");
    try {
      const data = await api("/api/insights");
      state.insightsStale = false;
      renderInsights(data);
    } catch (error) {
      box.textContent = "";
      box.append(h("p", { class: "form-error", text: error.message }));
    }
  }

  function jumpButton(id, name) {
    return h("button", { type: "button", class: "jump", onclick: () => selectConcept(id, { fit: true }) }, name);
  }

  function renderInsights(data) {
    const box = $("#insights");
    box.textContent = "";
    if (data.counts.concepts === 0) {
      box.append(h("p", { class: "empty-text", text: "Add some concepts and links, then come back for analysis." }));
      return;
    }

    box.append(h("div", { class: "stats" },
      [["concepts", data.counts.concepts], ["links", data.counts.relations], ["clusters", data.counts.clusters]]
        .map(([label, value]) => h("div", { class: "stat" }, h("strong", { text: String(value) }), h("span", { text: label })))));

    // Keystones
    const keystones = h("section", { class: "insight" },
      h("h3", { text: "Keystone concepts" }),
      h("p", { class: "why", text: "Ideas that lie on many of the shortest routes between other ideas, scored out of 100 against the top one. Remove one and parts of the graph can drift apart." }));
    if (data.keystones.length) {
      const top = Math.max.apply(null, data.keystones.map((k) => k.betweenness)) || 1;
      keystones.append(h("ul", { class: "rank" }, data.keystones.map((k) => h("li", null,
        jumpButton(k.id, k.name),
        h("span", { class: "meta" }, k.discipline + ", bridge score " + Math.round((k.betweenness / top) * 100))))));
    } else {
      keystones.append(h("p", { class: "empty-text", text: "Every concept is a dead end so far. Add a few more links to see bridges appear." }));
    }
    box.append(keystones);

    // Suggestions
    const suggestions = h("section", { class: "insight" },
      h("h3", { text: "Links that may be missing" }),
      h("p", { class: "why", text: "Pairs of concepts that are not linked but share at least two neighbours." }));
    if (data.suggestions.length) {
      data.suggestions.forEach((s) => {
        suggestions.append(h("div", { class: "suggestion" },
          h("p", null, jumpButton(s.firstId, s.firstName), " and ", jumpButton(s.secondId, s.secondName)),
          h("p", { class: "shared", text: "Both connect to " + s.shared.join(", ") + "." }),
          h("button", {
            type: "button", class: "button button-quiet button-small",
            onclick: async () => {
              try {
                await api("/api/relations", { method: "POST", body: { fromId: s.firstId, toId: s.secondId, label: "relates to", strength: 2 } });
                toast("Linked " + s.firstName + " and " + s.secondName + ".");
                await refresh();
              } catch (error) { toast(error.message, true); }
            }
          }, "Link them")));
      });
    } else {
      suggestions.append(h("p", { class: "empty-text", text: "No suggestions right now." }));
    }
    box.append(suggestions);

    // Discipline links
    const crossing = h("section", { class: "insight" },
      h("h3", { text: "Where disciplines meet" }),
      h("p", { class: "why", text: "How many links cross from one field into another." }));
    if (data.disciplineLinks.length) {
      crossing.append(h("ul", { class: "rank" }, data.disciplineLinks.map((l) => h("li", null,
        h("span", { text: l.first + " and " + l.second }), h("span", { class: "meta", text: l.count + (l.count === 1 ? " link" : " links") })))));
    } else {
      crossing.append(h("p", { class: "empty-text", text: "No links cross between disciplines yet." }));
    }
    box.append(crossing);

    // Clusters
    if (data.clusters.length > 1) {
      const clusters = h("section", { class: "insight" },
        h("h3", { text: "Separate clusters" }),
        h("p", { class: "why", text: "Groups with no link between them. A single link would join two clusters." }));
      clusters.append(h("ul", { class: "rank" }, data.clusters.map((c) => h("li", null,
        h("span", { text: c.sample.join(", ") + (c.size > c.sample.length ? " and " + (c.size - c.sample.length) + " more" : "") }),
        h("span", { class: "meta", text: c.size + (c.size === 1 ? " concept" : " concepts") })))));
      box.append(clusters);
    }

    // Orphans
    if (data.orphans.length) {
      const orphans = h("section", { class: "insight" },
        h("h3", { text: "Not linked yet" }),
        h("p", { class: "why", text: "Concepts with no links at all." }));
      orphans.append(h("ul", { class: "rank" }, data.orphans.map((c) => h("li", null, jumpButton(c.id, c.name), h("span", { class: "meta", text: c.discipline })))));
      box.append(orphans);
    }
  }

  // ------------------------------------------------------------------ demo, import, export

  async function loadDemo() {
    try {
      await api("/api/demo", { method: "POST" });
      toast("Demo graph loaded.");
      sim.reset = true;
      await refresh();
    } catch (error) { toast(error.message, true); }
  }
  $("#empty-demo").addEventListener("click", loadDemo);

  $("#import-button").addEventListener("click", () => $("#import-file").click());
  $("#import-file").addEventListener("change", async (event) => {
    const file = event.target.files[0];
    event.target.value = "";
    if (!file) return;
    let data;
    try {
      data = JSON.parse(await file.text());
    } catch (error) {
      toast("That file is not valid JSON.", true);
      return;
    }
    const count = Array.isArray(data.concepts) ? data.concepts.length : 0;
    if (!window.confirm("Importing replaces your whole graph with the " + count + " concepts in this file. Continue?")) return;
    try {
      await api("/api/import", { method: "POST", body: data });
      toast("Graph imported.");
      sim.reset = true;
      state.selectedId = null;
      clearResult();
      await refresh();
    } catch (error) { toast(error.message, true); }
  });

  // ------------------------------------------------------------------ start

  refresh().catch((error) => toast(error.message, true));
})();
